(function() {
	"use strict";

	angular
		.module('company-registry.place', ['ngResource', 'ui.router']);
})();