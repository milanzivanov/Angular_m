(function() {
	"use strict";

	angular
		.module('company-registry.place.place-modal', ['ngAnimate', 'ui.bootstrap']);
})();