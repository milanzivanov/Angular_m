(function() {
	"use strict";

	angular
		.module('company-registry.company', ['ngResource', 'ui.router', 'company-registry.place.place-modal']);
})();