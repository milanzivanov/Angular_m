(function() {
	"use strict";
	
	angular
		.module('company-registry.core', ['ui.router']);
})();