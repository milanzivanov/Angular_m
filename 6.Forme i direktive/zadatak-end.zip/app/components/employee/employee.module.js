(function() {
	"use strict";

	angular
		.module('company-registry.employee', ['ngResource', 'ui.router', 'company-registry.place.place-modal']);
})();