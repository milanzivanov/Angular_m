(function() {
	"use strict";
	
	angular
		.module('company-registry', ['company-registry.core', 'company-registry.place', 'company-registry.employee', 'company-registry.company', 'company-registry.shared']);
})();