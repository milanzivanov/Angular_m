(function() {
	"use strict";
	
	angular
		.module('company-registry.shared', ['company-registry.i18n', 'ngMessages']);
})();