(function() {
	"use strict";
	
	angular
		.module('company-registry.i18n', ['pascalprecht.translate', 'tmh.dynamicLocale', 'company-registry.i18n.constants']);
})();