require('./ui-bootstrap-tpls');
module.exports = 'ui.bootstrap';
