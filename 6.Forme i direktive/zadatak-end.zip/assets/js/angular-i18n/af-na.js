require('./angular-locale_af-na');
module.exports = 'ngLocale';
