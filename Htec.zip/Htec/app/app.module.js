(function(){
    'use strict';

    angular
        .module('htecApp', ['ui.router']);
}());