angular.module('app').controller('CompanyController', function($scope, $stateParams, $location, Company) {
	if($stateParams.id === "add") {
		$scope.company = {};
		$scope.title = "Add new company";
	} else {
		Company.get($stateParams.id).then(function(response) {
			$scope.company = response.data;
		});
		$scope.title = "Edit company with id " + $stateParams.id;
	}

	$scope.save = function() {
		if($scope.company._id) {
			Company.update($scope.company).then(success);
		} else {
			Company.create($scope.company).then(success);
		}
	};

	$scope.remove = function() {
		Company.remove($scope.company._id).then(success);
	};

	function success() {
		$location.path('/company');
	}
})
.controller('CompanyListController', function($scope, $location, Company) {
	$scope.filter = {};

	//Objekat koji sadrži podatke vezane za straničenje
	$scope.pagination = {
		page: 1,
		pageSize: 5,
		changePage: function(page) {
			$scope.pagination.page = page;
			getAll();
		}
	};

	getAll();

	$scope.tableChanged = function(sortParam) {
		if($scope.sort === sortParam) {
			$scope.sortDirection = $scope.sortDirection == 'asc' ? 'desc' : 'asc';
		} else {
			$scope.sort = sortParam;
			$scope.sortDirection = 'asc';
		}
		getAll();
	};

	$scope.search = function() {
		getAll();
	};

	$scope.edit = function(id) {
		$location.path("/company/"+id);
	};

	function getAll() {
		Company.getAll({sort: $scope.sort, sortDirection: $scope.sortDirection, filter: $scope.filter, page: $scope.pagination.page, pageSize: $scope.pagination.pageSize}).then(function(response) {
			$scope.companies = response.data.results;
			$scope.pagination.iterator = new Array(Math.ceil(response.data.count / $scope.pagination.pageSize));
		});		
	}
});