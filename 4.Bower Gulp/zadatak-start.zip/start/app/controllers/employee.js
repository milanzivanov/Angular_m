angular.module('app').controller('EmployeeController', function($scope, $stateParams, $location, Employee) {
	if($stateParams.id === "add") {
		$scope.employee = {};
		$scope.title = "Add new employee";
	} else {
		Employee.get($stateParams.id).then(function(response) {
			$scope.employee = response.data;
		});
		$scope.title = "Edit employee with id " + $stateParams.id;
	}

	$scope.save = function() {
		if($scope.employee._id) {
			Employee.update($scope.employee).then(success);
		} else {
			Employee.create($scope.employee).then(success);
		}
	};

	$scope.remove = function() {
		Employee.remove($scope.employee._id).then(success);
	};

	function success() {
		$location.path('/employee');
	}
})
.controller('EmployeeListController', function($scope, $location, Employee) {
	$scope.filter = {};

	//Objekat koji sadrži podatke vezane za straničenje
	$scope.pagination = {
		page: 1,
		pageSize: 5,
		changePage: function(page) {
			$scope.pagination.page = page;
			getAll();
		}
	};

	getAll();

	$scope.tableChanged = function(sortParam) {
		if($scope.sort === sortParam) {
			$scope.sortDirection = $scope.sortDirection == 'asc' ? 'desc' : 'asc';
		} else {
			$scope.sort = sortParam;
			$scope.sortDirection = 'asc';
		}
		getAll();
	};

	$scope.search = function() {
		getAll();
	};

	$scope.edit = function(id) {
		$location.path("/employee/"+id);
	};

	function getAll() {
		Employee.getAll({sort: $scope.sort, sortDirection: $scope.sortDirection, filter: $scope.filter, page: $scope.pagination.page, pageSize: $scope.pagination.pageSize}).then(function(response) {
			$scope.employees = response.data.results;
			$scope.pagination.iterator = new Array(Math.ceil(response.data.count / $scope.pagination.pageSize));
		});		
	}
});