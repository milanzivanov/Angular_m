angular.module('app').controller('SideBarController', function($scope, $location) {
	$scope.isActive = function(path) {
		return $location.path().indexOf(path) != -1;
	};
})