angular.module('app', ['ui.router']).config(function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/home');

	$stateProvider
		.state('companyList', {
			url: '/company',
			templateUrl: 'app/views/company-list.html'
		})
		.state('company', {
			url: '/company/:id',
			templateUrl: 'app/views/company.html'
		})
		.state('employeeList', {
			url: '/employee',
			templateUrl: 'app/views/employee-list.html'
		})
		.state('employee', {
			url: '/employee/:id',
			templateUrl: 'app/views/employee.html'
		})
		.state('home', {
			url: '/home',
			templateUrl: 'app/views/home.html'
		})
		.state('about', {
			url: '/about',
			templateUrl: 'app/views/about.html'
		});
});