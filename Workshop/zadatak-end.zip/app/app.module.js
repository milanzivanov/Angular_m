(function() {
	angular
		.module('new-imdb', ['new-imdb.core', 'new-imdb.movie']);
})();