(function() {
	angular
		.module('new-imdb.core', ['ui.router']);
})();