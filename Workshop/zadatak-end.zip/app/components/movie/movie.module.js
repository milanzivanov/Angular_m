(function() {
	angular
		.module('new-imdb.movie', ['ui.router', 'ngResource', 'ngMessages']);
})();